
type User = {
    uuid?: string;
    username: string;
    password?: string;
}

export default User;
